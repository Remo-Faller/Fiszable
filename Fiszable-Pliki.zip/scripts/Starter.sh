#!/bin/bash

# https://github.com/Remo-Faller/Fiszable

if [[ $(uname -o) == *'Android'* ]];then
	FISZABLE_ROOT="/data/data/com.termux/files/usr/opt/Fiszable"
else
	export FISZABLE_ROOT="/opt/Fiszable"
fi

if [[ $1 == '-p' || $1 == 'pomoc' ]]; then
	echo "Aby uruchomić Fiszable wpisz \`Fiszable\` w Terminalu"
	echo
	echo "Pomoc:"
	echo " -p | pomoc : Wyświetla tą informację"
	echo " -w | wynik : Wyświetla zapisane wyniki"
	echo " -a | adres : Wyświetla zapisane adresy"
	echo
elif [[ $1 == '-w' || $1 == 'wynik' ]]; then
	cat $FISZABLE_ROOT/auth/usernames.dat 2> /dev/null || { 
		echo "Brak Zapisanych Wyników !"
		exit 1
	}
elif [[ $1 == '-a' || $1 == 'adres' ]]; then
	cat $FISZABLE_ROOT/auth/ip.txt 2> /dev/null || {
		echo "Brak Zapisanych Adresów !"
		exit 1
	}
else
	cd $FISZABLE_ROOT
	bash ./Fiszable.sh
fi
